import express from "express"

export const login = (req, res) => res.send("<h1>Login</h1>");