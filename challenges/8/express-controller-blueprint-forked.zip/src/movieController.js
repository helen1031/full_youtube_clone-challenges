import {
  getMovieById,
  getMovies,
  getMovieByMinimumRating,
  getMovieByMinimumYear
} from "./db";

let movies = [];

export const home = (req, res) => {
  const movies = getMovies();
  res.render("home", { pageTitle: "Movies!", movies });
};
export const movieDetail = async (req, res) => {
  const { id } = req.params;
  console.log(id);
  const movie = await getMovieById(id);
  console.log(movie);
  res.render("detail", { pageTitle: `${movie.title}`, movie });
};
export const filterMovie = async (req, res) => {
  const { year, rating } = req.query;
  if (rating) {
    const movies = await getMovieByMinimumRating(rating);
    console.log(movies.size());
    return res.render("filter", {
      pageTitle: `Searching by Rating ${rating}`,
      movies
    });
  } else {
    const movies = await getMovieByMinimumYear(year);
    return res.render("filter", {
      pageTitle: `Searching by Year ${year}`,
      movies
    });
  }
};
